const colorPicker = document.getElementById('colorPicker');
const colorValue = document.getElementById('colorValue');

colorPicker.addEventListener('input', function() {
    const selectedColor = colorPicker.value;
    document.body.style.backgroundColor = selectedColor;
    colorValue.textContent = selectedColor;
});