let playerScore = 0;
let computerScore = 0;

function play(playerChoice) {
    const choices = ['pedra', 'papel', 'tesoura'];
    const computerChoice = choices[Math.floor(Math.random() * 3)];
    const result = getResult(playerChoice, computerChoice);
    updateScore(result);
    displayResult(playerChoice, computerChoice, result);
}

function getResult(player, computer) {
    if (player === computer) return 'Empate';
    if ((player === 'pedra' && computer === 'tesoura') ||
        (player === 'papel' && computer === 'pedra') ||
        (player === 'tesoura' && computer === 'papel')) {
        return 'Vitória';
    }
    return 'Derrota';
}

function updateScore(result) {
    if (result === 'Vitória') playerScore++;
    if (result === 'Derrota') computerScore++;
    document.getElementById('score').textContent = `Jogador: ${playerScore} - Computador: ${computerScore}`;
}

function displayResult(player, computer, result) {
    const resultDiv = document.getElementById('result');
    resultDiv.innerHTML = `
        Você escolheu: <img src="${getImageUrl(player)}" alt="${player}" width="50" height="50">
        <br>
        Computador escolheu: <img src="${getImageUrl(computer)}" alt="${computer}" width="50" height="50">
        <br>
        ${result}!
    `;
}

function getImageUrl(choice) {
    switch(choice) {
        case 'pedra': return 'https://openmoji.org/data/color/svg/1F5FF.svg';
        case 'papel': return 'https://openmoji.org/data/color/svg/1F4C4.svg';
        case 'tesoura': return 'https://openmoji.org/data/color/svg/2702.svg';
    }
}